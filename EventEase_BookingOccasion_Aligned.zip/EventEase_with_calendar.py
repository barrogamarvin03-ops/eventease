import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import importlib
import os
import sqlite3
import hashlib
import csv
try:
    qrcode = importlib.import_module("qrcode")
except ImportError:
    qrcode = None
try:
    Image = importlib.import_module("PIL.Image")
    ImageTk = importlib.import_module("PIL.ImageTk")
    ImageOps = importlib.import_module("PIL.ImageOps")
except ImportError:
    Image = None
    ImageTk = None
try:
    docx = importlib.import_module("docx")
except ImportError:
    docx = None
import random
import shutil
import calendar as pycalendar
from datetime import datetime, date, timedelta

# ==========================================
# DATA
# ==========================================
reservations = []
packages = {
    'Birthday': {
        'Basic': 5000,
        'Premium': 11000,
        'Deluxe': 18000
    },
    'Wedding': {
        'Basic': 15000,
        'Premium': 25000,
        'Deluxe': 40000
    },
    'Anniversary': {
        'Basic': 5000,
        'Premium': 8000,
        'Deluxe': 12000
    },
    'Graduation': {
        'Basic': 4000,
        'Premium': 7000,
        'Deluxe': 10000
    },
    'jS Prom': {
        'Basic': 5000,
        'Premium': 7500,
        'Deluxe': 10000
    },
    'Corporate Event': {
        'Basic': 10000,
        'Premium': 20000,
        'Deluxe': 30000
    },
    'Debut': {
        'Basic': 12000,
        'Premium': 20000,
        'Deluxe': 30000
    },
    'Christening': {
        'Basic': 6000,
        'Premium': 9000,
        'Deluxe': 12000
    },
    'Christmas Party': {
        'Basic': 8000,
        'Premium': 15000,
        'Deluxe': 25000
    },
    'baby shower': {
        'Basic': 5000,
        'Premium': 8000,
        'Deluxe': 12000
    },
    'Seminar / Workshop': {
        'Basic': 7000,
        'Premium': 12000,
        'Deluxe': 18000
    },
    'Awarding Ceremony': {
        'Basic': 8000,
        'Premium': 14000,
        'Deluxe': 20000
    },
    'Housewarming': {
        'Basic': 5000,
        'Premium': 8000,
        'Deluxe': 11000
    },
    'Family Reunion': {
        'Basic': 6000,
        'Premium': 10000,
        'Deluxe': 15000
    },
    'School event': {
        'Basic': 5000,
        'Premium': 9000,
        'Deluxe': 13000
    }
}
DISCOUNT_CODE = "SAVE20"
DISCOUNT_PERCENT = 20

# ==========================================
# DATABASE (SQLite) - reservations persist between runs
# ==========================================
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reservations.db")
db_conn = sqlite3.connect(DB_PATH)
db_cursor = db_conn.cursor()
db_cursor.execute("""
CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact TEXT NOT NULL,
    occasion TEXT NOT NULL,
    package TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    guests INTEGER NOT NULL,
    price REAL NOT NULL,
    discounted INTEGER NOT NULL DEFAULT 0
)
""")
db_conn.commit()

# Add new reservation fields without deleting existing data
for _column, _definition in [
    ("amount_paid", "REAL NOT NULL DEFAULT 0"),
    ("payment_status", "TEXT NOT NULL DEFAULT 'Unpaid'")
]:
    try:
        db_cursor.execute(f"ALTER TABLE reservations ADD COLUMN {_column} {_definition}")
    except sqlite3.OperationalError:
        pass  # Column already exists
db_conn.commit()

db_cursor.execute("""
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL
)
""")
db_conn.commit()


def hash_password(plain_text_password):
    return hashlib.sha256(plain_text_password.encode("utf-8")).hexdigest()


# Seed a default admin account on first run only, so the app works
# out of the box. Change the password from inside the app afterward
# (or directly in the database) rather than editing this seed value.
DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "admin123"

db_cursor.execute("SELECT COUNT(*) FROM admins")
if db_cursor.fetchone()[0] == 0:
    db_cursor.execute(
        "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
        (DEFAULT_ADMIN_USERNAME, hash_password(DEFAULT_ADMIN_PASSWORD))
    )
    db_conn.commit()

# Drop a file named "logo.png" next to this script to use your own picture
# in the heading frame. If it isn't found (or Pillow isn't installed), a
# generated calendar icon is drawn instead, so the header always looks complete.
LOGO_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logo.png")
DASHBOARD_BANNER_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "eventease_dashboard_banner.png")

# Shared color palette (used by both the login screen and the main app)
COLOR_DARK = "#101828"
COLOR_ACCENT = "#2878F0"
COLOR_ACCENT_HOVER = "#1E5FC7"
COLOR_BG = "#F4F6F8"
COLOR_DANGER = "#D64545"
COLOR_DANGER_HOVER = "#B93A3A"
COLOR_SUCCESS = "#00C853"
COLOR_MUTED = "#687386"


# ==========================================
# SMALL UI HELPERS (hover effects)
# ==========================================
def _tint(hex_color, amount):
    """Lighten a hex color toward white. amount=0 -> unchanged, amount=1 -> white."""
    hex_color = hex_color.lstrip("#")
    if len(hex_color) != 6:
        return "#FFFFFF"
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    r = int(r + (255 - r) * amount)
    g = int(g + (255 - g) * amount)
    b = int(b + (255 - b) * amount)
    return f"#{r:02X}{g:02X}{b:02X}"


def add_hover(widget, normal_bg, hover_bg):
    """Give any tk.Button a smooth color change on mouse hover."""
    def on_enter(_e):
        widget.config(bg=hover_bg)

    def on_leave(_e):
        widget.config(bg=normal_bg)

    widget.bind("<Enter>", on_enter)
    widget.bind("<Leave>", on_leave)


def draw_calendar_icon(canvas, cx, cy, size=64):
    """Draws a simple flat-style calendar/event icon centered at (cx, cy)."""
    half = size // 2
    top = cy - half
    bottom = cy + half
    left = cx - half
    right = cx + half

    canvas.create_rectangle(left, top + 10, right, bottom, fill="white", outline="#101828", width=2)
    canvas.create_rectangle(left, top + 10, right, top + 26, fill=COLOR_ACCENT, outline=COLOR_ACCENT)
    canvas.create_rectangle(left + 10, top, left + 16, top + 16, fill="#101828", outline="")
    canvas.create_rectangle(right - 16, top, right - 10, top + 16, fill="#101828", outline="")
    grid_left = left + 8
    grid_top = top + 34
    cell_w, cell_h, gap = 12, 9, 4
    for row in range(2):
        for col in range(3):
            x0 = grid_left + col * (cell_w + gap)
            y0 = grid_top + row * (cell_h + gap)
            fill = COLOR_DANGER if (row, col) == (0, 1) else "#D1D5DB"
            canvas.create_rectangle(x0, y0, x0 + cell_w, y0 + cell_h, fill=fill, outline="")


def build_logo_widget(parent, box_bg="white"):
    """
    Returns a small 'picture frame' style widget:
    - shows logo.png (next to this script) if it exists and Pillow is available
    - otherwise falls back to a drawn calendar/event icon, so the frame is
      never empty.
    """
    frame = tk.Frame(parent, bg=box_bg, highlightbackground=COLOR_ACCENT, highlightthickness=2)
    inner = tk.Frame(frame, bg=box_bg)
    inner.pack(padx=6, pady=6)

    if Image is not None and ImageTk is not None and os.path.exists(LOGO_PATH):
        try:
            # Use the supplied EventEase logo and preserve its transparent background.
            img = Image.open(LOGO_PATH).convert("RGBA")
            img.thumbnail((205, 150), Image.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            logo_label = tk.Label(inner, image=photo, bg=box_bg, bd=0)
            logo_label.image = photo  # keep a reference so it isn't garbage-collected
            logo_label.pack()
            return frame
        except Exception:
            pass  # any load problem -> fall back to the drawn icon below

    canvas = tk.Canvas(inner, width=72, height=72, bg=box_bg, highlightthickness=0)
    canvas.pack()
    draw_calendar_icon(canvas, 36, 36, size=60)
    return frame


# ==========================================
# LOGIN SCREEN
# ==========================================
def show_login_screen():
    login = tk.Tk()
    login.title("EventEase Pro - Admin Login")
    login.geometry("900x520")
    login.resizable(False, False)
    login.configure(bg=COLOR_BG)

    # Center the window on screen
    login.update_idletasks()
    w, h = 900, 520
    x = (login.winfo_screenwidth() // 2) - (w // 2)
    y = (login.winfo_screenheight() // 2) - (h // 2)
    login.geometry(f"{w}x{h}+{x}+{y}")

    # --- Left branding panel (dark) ---
    left_panel = tk.Frame(login, bg=COLOR_DARK, width=380)
    left_panel.pack(side="left", fill="y")
    left_panel.pack_propagate(False)

    branding_wrap = tk.Frame(left_panel, bg=COLOR_DARK)
    branding_wrap.place(relx=0.5, rely=0.5, anchor="center")

    logo_widget = build_logo_widget(branding_wrap, box_bg=COLOR_DARK)
    logo_widget.pack(pady=(0, 20))

    tk.Label(
        branding_wrap, text="EVENTEASE\nMANAGER", font=("Segoe UI", 26, "bold"),
        fg="white", bg=COLOR_DARK, justify="center"
    ).pack()
    tk.Label(
        branding_wrap, text="PRO EDITION • 2026", font=("Segoe UI", 10, "bold"),
        fg=COLOR_ACCENT, bg=COLOR_DARK
    ).pack(pady=(4, 0))
    tk.Frame(branding_wrap, bg=COLOR_ACCENT, width=50, height=3).pack(pady=16)
    tk.Label(
        branding_wrap,
        text="Reservation • Catering\nEvent Planning System",
        font=("Segoe UI", 9), fg="#9AA5B8", bg=COLOR_DARK, justify="center"
    ).pack()

    # --- Right login form panel (white) ---
    right_panel = tk.Frame(login, bg="white")
    right_panel.pack(side="right", fill="both", expand=True)

    form_wrap = tk.Frame(right_panel, bg="white")
    form_wrap.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(
        form_wrap, text="Admin Login", font=("Segoe UI", 22, "bold"),
        fg=COLOR_DARK, bg="white"
    ).grid(row=0, column=0, sticky="w", pady=(0, 4))
    tk.Label(
        form_wrap, text="Sign in to manage reservations and settings.",
        font=("Segoe UI", 10), fg=COLOR_MUTED, bg="white"
    ).grid(row=1, column=0, sticky="w", pady=(0, 25))

    tk.Label(
        form_wrap, text="USERNAME", font=("Segoe UI", 8, "bold"),
        fg=COLOR_MUTED, bg="white"
    ).grid(row=2, column=0, sticky="w")
    username_entry = tk.Entry(
        form_wrap, font=("Segoe UI", 12), width=28, bd=0,
        relief="flat", highlightthickness=1,
        highlightbackground="#D9DEE7", highlightcolor=COLOR_ACCENT
    )
    username_entry.grid(row=3, column=0, sticky="ew", pady=(4, 16), ipady=8)
    username_entry.focus()

    tk.Label(
        form_wrap, text="PASSWORD", font=("Segoe UI", 8, "bold"),
        fg=COLOR_MUTED, bg="white"
    ).grid(row=4, column=0, sticky="w")
    password_entry = tk.Entry(
        form_wrap, font=("Segoe UI", 12), width=28, bd=0,
        relief="flat", show="•", highlightthickness=1,
        highlightbackground="#D9DEE7", highlightcolor=COLOR_ACCENT
    )
    password_entry.grid(row=5, column=0, sticky="ew", pady=(4, 8), ipady=8)

    remembered_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".remembered_user.txt")
    if os.path.exists(remembered_file):
        try:
            with open(remembered_file, "r") as f:
                saved_username = f.read().strip()
            if saved_username:
                username_entry.delete(0, tk.END)
                username_entry.insert(0, saved_username)
                password_entry.focus()
        except Exception:
            pass

    show_pw_var = tk.BooleanVar()
    remember_var = tk.BooleanVar(value=os.path.exists(remembered_file))

    def toggle_password():
        password_entry.config(show="" if show_pw_var.get() else "•")

    checks_row = tk.Frame(form_wrap, bg="white")
    checks_row.grid(row=6, column=0, sticky="w", pady=(0, 8))

    tk.Checkbutton(
        checks_row, text="Show password", variable=show_pw_var, command=toggle_password,
        font=("Segoe UI", 8), bg="white", fg=COLOR_MUTED,
        activebackground="white", bd=0
    ).pack(side="left")

    tk.Checkbutton(
        checks_row, text="Remember me", variable=remember_var,
        font=("Segoe UI", 8), bg="white", fg=COLOR_MUTED,
        activebackground="white", bd=0
    ).pack(side="left", padx=(15, 0))

    error_label = tk.Label(form_wrap, text="", font=("Segoe UI", 8, "bold"), fg=COLOR_DANGER, bg="white")
    error_label.grid(row=7, column=0, sticky="w")

    def attempt_login(event=None):
        username = username_entry.get().strip()
        password = password_entry.get().strip()

        db_cursor.execute("SELECT password_hash FROM admins WHERE username = ?", (username,))
        result = db_cursor.fetchone()
        login_ok = result is not None and result[0] == hash_password(password)

        if login_ok:
            try:
                if remember_var.get():
                    with open(remembered_file, "w") as f:
                        f.write(username)
                elif os.path.exists(remembered_file):
                    os.remove(remembered_file)
            except Exception:
                pass
            login.destroy()
            launch_main_app()
        else:
            error_label.config(text="Invalid username or password. Please try again.")
            password_entry.delete(0, tk.END)

    login_btn = tk.Button(
        form_wrap, text="LOGIN", bg=COLOR_ACCENT, fg="white",
        font=("Segoe UI", 11, "bold"), relief="flat", bd=0,
        height=2, width=28, command=attempt_login, cursor="hand2"
    )
    login_btn.grid(row=8, column=0, sticky="ew", pady=(15, 0))
    add_hover(login_btn, COLOR_ACCENT, COLOR_ACCENT_HOVER)

    login.bind("<Return>", attempt_login)

    tk.Label(
        form_wrap, text="Default demo credentials: admin / admin123",
        font=("Segoe UI", 8), fg="#B7BFCC", bg="white"
    ).grid(row=9, column=0, sticky="w", pady=(18, 0))

    login.mainloop()


# ==========================================
# MAIN APP
# ==========================================
def launch_main_app():
    # ------------------------------------------
    # FUNCTIONS
    # ------------------------------------------
    editing_id = [None]
    # ================= DYNAMIC EVENT DESIGN =================
    def update_event_banner(occasion=None):
        """Change the top EventEase banner design based on the selected occasion."""
        try:
            canvas = event_banner_canvas
            canvas.delete("all")
            w = max(canvas.winfo_width(), 900)
            h = 300

            designs = {
                "Birthday": ("BIRTHDAY CELEBRATION", "Make every birthday memorable", "#FF6B8A", "#FFC371"),
                "Wedding": ("WEDDING DAY", "A beautiful day made special", "#9B7EDE", "#F6C7D7"),
                "Anniversary": ("ANNIVERSARY", "Celebrate love and memories", "#E85D75", "#F7B2C4"),
                "Graduation": ("GRADUATION", "Celebrate your achievement", "#2878F0", "#63D2FF"),
                "Baby Shower": ("BABY SHOWER", "A sweet celebration for the little one", "#65B7E8", "#B8E8FF"),
                "Corporate Event": ("CORPORATE EVENT", "Professional events made easy", "#263B73", "#4EA8DE"),
                "Debut": ("DEBUT CELEBRATION", "A special milestone to remember", "#B45FC8", "#F3A7D5"),
                "Christening": ("CHRISTENING", "A meaningful day with family", "#5FA8D3", "#CAE9FF"),
                "Christmas Party": ("CHRISTMAS PARTY", "Celebrate, share and enjoy", "#238636", "#E85D75"),
                "Seminar / Workshop": ("SEMINAR / WORKSHOP", "Learn, connect and grow", "#1769AA", "#64B5F6"),
                "Awarding Ceremony": ("AWARDING CEREMONY", "Recognize success and achievement", "#B8860B", "#F7D774"),
                "Housewarming": ("HOUSEWARMING", "Celebrate your new home", "#A05A2C", "#F2C078"),
                "Family Reunion": ("FAMILY REUNION", "Bringing family and memories together", "#2A9D8F", "#90E0EF"),
                "Reunion Party": ("REUNION PARTY", "Good friends, great memories", "#4361EE", "#72EFDD"),
            }

            if occasion in designs:
                title, subtitle, c1, c2 = designs[occasion]

                # Main banner for a selected occasion.
                canvas.configure(bg=c1, height=h)
                canvas.create_rectangle(0, 0, w, h, fill=c1, outline=c1)
                # Decorative circles and shapes
                canvas.create_oval(w-210, -75, w+50, 185, fill=c2, outline="")
                canvas.create_oval(w-120, 105, w+80, 305, fill="white", outline="", stipple="gray50")
                canvas.create_oval(-80, 130, 100, 310, fill=c2, outline="")
                canvas.create_rectangle(0, 0, 12, h, fill="white", outline="")

                # Simple sparkle accents
                for x, y in [(w-300, 42), (w-250, 105), (w-365, 155), (100, 42), (145, 155)]:
                    canvas.create_text(x, y, text="✦", fill="white", font=("Segoe UI Symbol", 18, "bold"))

                canvas.create_text(45, 70, text=title, anchor="w", fill="white", font=("Segoe UI", 28, "bold"))
                canvas.create_text(45, 112, text=subtitle, anchor="w", fill="white", font=("Segoe UI", 13, "bold"))
                canvas.create_text(45, 158, text="EVENTEASE  •  RESERVATION  •  EVENT PLANNING", anchor="w", fill="white", font=("Segoe UI", 8, "bold"))
            else:
                # Before an occasion is selected, show the polished EventEase
                # hero banner. It uses the EventEase logo plus a purple/gold
                # decorative background so the dashboard already looks complete.
                canvas.configure(bg="#F7F0FF", height=h)
                canvas.create_rectangle(0, 0, w, h, fill="#F7F0FF", outline="#F7F0FF")

                if Image is not None and ImageTk is not None and os.path.exists(DASHBOARD_BANNER_PATH):
                    try:
                        banner_img = Image.open(DASHBOARD_BANNER_PATH).convert("RGB")
                        # Keep the banner proportions so the logo and text never look stretched.
                        try:
                            from PIL import ImageOps
                            banner_img = ImageOps.contain(banner_img, (w, h), method=Image.LANCZOS)
                        except Exception:
                            banner_img.thumbnail((w, h), Image.LANCZOS)
                        banner_photo = ImageTk.PhotoImage(banner_img)
                        canvas.image = banner_photo  # keep reference alive
                        canvas.create_image(0, 0, image=banner_photo, anchor="nw")
                    except Exception:
                        # Fallback: keep the logo visible if the banner image cannot load.
                        if Image is not None and ImageTk is not None and os.path.exists(LOGO_PATH):
                            try:
                                logo_img = Image.open(LOGO_PATH).convert("RGBA")
                                logo_img.thumbnail((460, 190), Image.LANCZOS)
                                logo_photo = ImageTk.PhotoImage(logo_img)
                                canvas.image = logo_photo
                                canvas.create_image(w // 2, h // 2, image=logo_photo, anchor="center")
                            except Exception:
                                canvas.create_text(
                                    w // 2, h // 2, text="EVENTEASE", anchor="center",
                                    fill=COLOR_ACCENT, font=("Segoe UI", 34, "bold")
                                )
                        else:
                            canvas.create_text(
                                w // 2, h // 2, text="EVENTEASE", anchor="center",
                                fill=COLOR_ACCENT, font=("Segoe UI", 34, "bold")
                            )
        except Exception:
            pass

    def update_packages(event=None):
        occasion = occasion_combo.get()
        if occasion:
            package_combo["values"] = list(packages[occasion].keys())
            package_combo.current(0)
            update_event_banner(occasion)
            update_price_preview()

    def update_price_preview(event=None):
        try:
            occasion = occasion_combo.get()
            package = package_combo.get()
            if occasion and package:
                price = packages[occasion][package]
                code = discount_entry.get().strip().upper()
                if code == "ENTER DISCOUNT CODE":
                    code = ""
                if code == DISCOUNT_CODE:
                    discount = price * (DISCOUNT_PERCENT / 100)
                    final_price = price - discount
                    price_label.config(text=f"₱{final_price:,.0f} (was ₱{price:,}) -{DISCOUNT_PERCENT}% OFF!", fg=COLOR_SUCCESS)
                else:
                    price_label.config(text=f"₱{price:,}", fg=COLOR_ACCENT)
        except Exception:
            pass

    def clear_fields():
        for e in [name_entry, contact_entry, date_entry, time_entry, guests_entry, discount_entry, amount_paid_entry]:
            e.delete(0, tk.END)
        occasion_combo.set("")
        package_combo.set("")
        update_event_banner()
        payment_status_combo.set("Unpaid")
        price_label.config(text="₱0", fg=COLOR_ACCENT)
        editing_id[0] = None
        create_btn.config(text="CREATE RESERVATION", command=make_reservation)

    def load_reservations_from_db():
        global reservations
        db_cursor.execute(
            "SELECT id, name, contact, occasion, package, date, time, guests, price, discounted, amount_paid, payment_status "
            "FROM reservations ORDER BY id"
        )
        rows = db_cursor.fetchall()
        reservations = [
            {
                "id": row[0], "name": row[1], "contact": row[2], "occasion": row[3],
                "package": row[4], "date": row[5], "time": row[6], "guests": row[7],
                "price": row[8], "discounted": bool(row[9]),
                "amount_paid": row[10], "payment_status": row[11]
            }
            for row in rows
        ]

    def reservation_conflict(date, time, exclude_id=None):
        db_cursor.execute(
            "SELECT id, name FROM reservations WHERE date = ? AND time = ? AND id != ?",
            (date, time, exclude_id or -1)
        )
        return db_cursor.fetchone()

    def calculate_payment(price):
        try:
            paid = float(amount_paid_entry.get().strip() or 0)
        except ValueError:
            raise ValueError("Amount paid must be a valid number.")
        if paid < 0 or paid > price:
            raise ValueError("Amount paid cannot be negative or greater than the total price.")
        status = payment_status_combo.get() or "Unpaid"
        if paid >= price:
            status = "Paid"
        elif paid > 0:
            status = "Partial"
        else:
            status = "Unpaid"
        return paid, status

    def edit_selected_reservation():
        selected = reservation_table.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Select a reservation to edit first.")
            return
        reservation_id = int(reservation_table.item(selected[0], "values")[0])
        r = next((res for res in reservations if res["id"] == reservation_id), None)
        if not r:
            messagebox.showerror("Error", "Reservation not found.")
            return
        clear_fields()
        name_entry.delete(0, tk.END); name_entry.insert(0, r["name"])
        contact_entry.delete(0, tk.END); contact_entry.insert(0, r["contact"])
        occasion_combo.set(r["occasion"]); update_packages()
        package_combo.set(r["package"]); update_price_preview()
        date_entry.delete(0, tk.END); date_entry.insert(0, r["date"])
        time_entry.delete(0, tk.END); time_entry.insert(0, r["time"])
        guests_entry.delete(0, tk.END); guests_entry.insert(0, str(r["guests"]))
        discount_entry.delete(0, tk.END)
        if r["discounted"]:
            discount_entry.insert(0, DISCOUNT_CODE)
        amount_paid_entry.delete(0, tk.END); amount_paid_entry.insert(0, str(r.get("amount_paid", 0)))
        payment_status_combo.set(r.get("payment_status", "Unpaid"))
        editing_id[0] = reservation_id
        create_btn.config(text="UPDATE RESERVATION", command=update_reservation)
        messagebox.showinfo("Edit Mode", "Update the details then click UPDATE RESERVATION.")

    def validate_contact_number(contact_text):
        """Require a contact number made of exactly 11 digits."""
        value = str(contact_text).strip()

        if not value or value.lower() == "e.g. 0917 123 4567":
            return False, "Please enter a contact number."

        if not value.isdigit():
            return False, "Contact Number must contain digits only. Do not use spaces, letters, or symbols."

        if len(value) < 11:
            return False, f"Contact Number is incomplete. You entered {len(value)} digits. It must be exactly 11 digits."

        if len(value) > 11:
            return False, f"Contact Number is too long. You entered {len(value)} digits. It must be exactly 11 digits."

        return True, None

    def validate_reservation_time(time_text):
        """Require a real clock time using Philippine local clock format."""
        value = str(time_text).strip()

        if not value or value.lower() == "e.g. 10:00 am":
            return None, "Please enter a reservation time."

        parsed = None
        # Accept normal 12-hour time such as 10:30 AM / 2:00 PM.
        # Also accept 24-hour input such as 14:00, then normalize it.
        for fmt in ("%I:%M %p", "%I:%M%p", "%H:%M"):
            try:
                parsed = datetime.strptime(value.upper(), fmt)
                break
            except ValueError:
                pass

        if parsed is None:
            return None, (
                "Invalid time. Please enter a real time, for example "
                "10:00 AM or 2:30 PM. Minutes must be from 00 to 59."
            )

        # Store/display the time consistently in 12-hour Philippine clock format.
        return parsed.strftime("%I:%M %p"), None

    def validate_reservation_date(date_text):
        """Allow today and future reservation dates only."""
        value = str(date_text).strip()

        if not value or value.lower() == "mm/dd/yyyy":
            return None, "Please enter a reservation date."

        parsed = None
        for fmt in ("%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d"):
            try:
                parsed = datetime.strptime(value, fmt).date()
                break
            except ValueError:
                pass

        if parsed is None:
            return None, "Invalid date. Please use MM/DD/YYYY, for example 10/20/2026."

        today = date.today()
        if parsed < today:
            return None, (
                f"Past dates are not allowed.\n\n"
                f"Today is {today.strftime('%B %d, %Y')}.\n"
                f"Please choose today or a future date."
            )

        return parsed, None

    def open_date_picker():
        """Open a calendar where past days and past months cannot be selected."""
        today = date.today()
        picker = tk.Toplevel(window)
        picker.title("EventEase - Select Reservation Date")
        picker.geometry("410x470")
        picker.resizable(False, False)
        picker.configure(bg="white")
        picker.transient(window)
        picker.grab_set()

        existing = parse_event_date(date_entry.get().strip())
        if existing and existing >= today:
            state = [existing.year, existing.month]
        else:
            state = [today.year, today.month]

        header = tk.Frame(picker, bg=COLOR_DARK)
        header.pack(fill="x")
        title_label = tk.Label(
            header, text="", font=("Segoe UI", 16, "bold"),
            bg=COLOR_DARK, fg="white"
        )
        title_label.pack(pady=14)

        body = tk.Frame(picker, bg="white")
        body.pack(fill="both", expand=True, padx=15, pady=12)

        nav = tk.Frame(body, bg="white")
        nav.pack(fill="x", pady=(0, 10))

        days_frame = tk.Frame(body, bg="white")
        days_frame.pack(fill="both", expand=True)

        def select_date(selected_date):
            if selected_date < today:
                return
            date_entry.delete(0, tk.END)
            date_entry.insert(0, selected_date.strftime("%m/%d/%Y"))
            date_entry.config(fg=COLOR_DARK)
            picker.destroy()

        def go_today():
            state[:] = [today.year, today.month]
            render_calendar()

        def previous_month():
            y, m = state
            if (y, m) <= (today.year, today.month):
                return
            m -= 1
            if m == 0:
                m, y = 12, y - 1
            state[:] = [y, m]
            render_calendar()

        def next_month():
            y, m = state
            m += 1
            if m == 13:
                m, y = 1, y + 1
            state[:] = [y, m]
            render_calendar()

        def render_calendar():
            for widget in nav.winfo_children():
                widget.destroy()
            for widget in days_frame.winfo_children():
                widget.destroy()

            y, m = state
            title_label.config(text=f"📅 {pycalendar.month_name[m]} {y}")

            previous_allowed = (y, m) > (today.year, today.month)
            tk.Button(
                nav, text="‹", font=("Segoe UI", 16, "bold"), width=3,
                bg="#EEF4FF" if previous_allowed else "#F1F1F1",
                fg=COLOR_ACCENT if previous_allowed else "#B8B8B8",
                activebackground="#DDEAFF", relief="flat", bd=0,
                state="normal" if previous_allowed else "disabled",
                command=previous_month
            ).pack(side="left")

            tk.Button(
                nav, text="Today", font=("Segoe UI", 8, "bold"),
                bg="#EEF4FF", fg=COLOR_ACCENT,
                activebackground="#DDEAFF", relief="flat", bd=0,
                cursor="hand2", command=go_today
            ).pack(side="left", padx=8)

            tk.Button(
                nav, text="›", font=("Segoe UI", 16, "bold"), width=3,
                bg="#EEF4FF", fg=COLOR_ACCENT,
                activebackground="#DDEAFF", relief="flat", bd=0,
                cursor="hand2", command=next_month
            ).pack(side="right")

            weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            for col, name in enumerate(weekdays):
                days_frame.grid_columnconfigure(col, weight=1)
                tk.Label(
                    days_frame, text=name, font=("Segoe UI", 8, "bold"),
                    bg="#F4F6F8", fg=COLOR_MUTED, pady=7
                ).grid(row=0, column=col, sticky="nsew", padx=1, pady=1)

            weeks = pycalendar.monthcalendar(y, m)
            for row, week in enumerate(weeks, start=1):
                days_frame.grid_rowconfigure(row, weight=1)
                for col, day_number in enumerate(week):
                    if day_number == 0:
                        tk.Label(
                            days_frame, text="", bg="white"
                        ).grid(row=row, column=col, sticky="nsew", padx=1, pady=1)
                        continue

                    selected_date = date(y, m, day_number)
                    is_past = selected_date < today
                    is_today = selected_date == today

                    if is_past:
                        btn = tk.Button(
                            days_frame, text=str(day_number),
                            font=("Segoe UI", 10), bg="#F1F1F1", fg="#B8B8B8",
                            disabledforeground="#B8B8B8", relief="flat", bd=0,
                            state="disabled"
                        )
                    else:
                        btn = tk.Button(
                            days_frame, text=str(day_number),
                            font=("Segoe UI", 10, "bold") if is_today else ("Segoe UI", 10),
                            bg=COLOR_ACCENT if is_today else "white",
                            fg="white" if is_today else COLOR_DARK,
                            activebackground=COLOR_ACCENT_HOVER if is_today else "#EEF4FF",
                            activeforeground="white" if is_today else COLOR_ACCENT,
                            relief="flat", bd=0, cursor="hand2",
                            command=lambda d=selected_date: select_date(d)
                        )
                    btn.grid(row=row, column=col, sticky="nsew", padx=2, pady=2)

        tk.Label(
            picker,
            text="🔒 Past dates are disabled • Today and future dates are available",
            font=("Segoe UI", 8, "bold"), bg="white", fg=COLOR_MUTED
        ).pack(pady=(0, 12))

        render_calendar()

    def update_reservation():
        if editing_id[0] is None:
            make_reservation()
            return
        reservation_id = editing_id[0]
        name = name_entry.get().strip(); contact = contact_entry.get().strip()
        occasion = occasion_combo.get(); package = package_combo.get()
        date = date_entry.get().strip(); time = time_entry.get().strip(); guests = guests_entry.get().strip()
        discount_code = discount_entry.get().strip().upper()
        if discount_code == "ENTER DISCOUNT CODE":
            discount_code = ""
        if not all([name, contact, occasion, package, date, time, guests]):
            messagebox.showwarning("Missing Information", "Please complete all required fields.")
            return
        valid_contact, contact_error = validate_contact_number(contact)
        if not valid_contact:
            messagebox.showerror("Invalid Contact Number", contact_error)
            contact_entry.focus_set()
            return
        parsed_date, date_error = validate_reservation_date(date)
        if date_error:
            messagebox.showerror("Invalid Reservation Date", date_error)
            return
        date = parsed_date.strftime("%m/%d/%Y")
        valid_time, time_error = validate_reservation_time(time)
        if time_error:
            messagebox.showerror("Invalid Reservation Time", time_error)
            time_entry.focus_set()
            return
        time = valid_time
        try:
            guests = int(guests)
            if guests <= 0: raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Number", "Guests must be > 0"); return
        conflict = reservation_conflict(date, time, reservation_id)
        if conflict:
            messagebox.showerror("Schedule Conflict", f"That date and time is already booked by {conflict[1]}.")
            return
        price = packages[occasion][package]; is_discounted = False
        if discount_code == DISCOUNT_CODE:
            price *= (1 - DISCOUNT_PERCENT / 100); is_discounted = True
        elif discount_code:
            messagebox.showerror("Invalid Code", f"Code '{discount_code}' is invalid. Use {DISCOUNT_CODE}"); return
        try:
            paid, status = calculate_payment(price)
        except ValueError as e:
            messagebox.showerror("Invalid Payment", str(e)); return
        db_cursor.execute("""UPDATE reservations SET name=?, contact=?, occasion=?, package=?, date=?, time=?, guests=?, price=?, discounted=?, amount_paid=?, payment_status=? WHERE id=?""",
                          (name, contact, occasion, package, date, time, guests, price, int(is_discounted), paid, status, reservation_id))
        db_conn.commit(); load_reservations_from_db(); update_table(); update_dashboard(); clear_fields()
        messagebox.showinfo("Updated", "Reservation updated successfully.")

    def make_reservation():
        name = name_entry.get().strip()
        contact = contact_entry.get().strip()
        occasion = occasion_combo.get()
        package = package_combo.get()
        date = date_entry.get().strip()
        time = time_entry.get().strip()
        guests = guests_entry.get().strip()
        discount_code = discount_entry.get().strip().upper()
        if discount_code == "ENTER DISCOUNT CODE":
            discount_code = ""

        if not all([name, contact, occasion, package, date, time, guests]):
            messagebox.showwarning("Missing Information", "Please complete all required fields.")
            return
        valid_contact, contact_error = validate_contact_number(contact)
        if not valid_contact:
            messagebox.showerror("Invalid Contact Number", contact_error)
            contact_entry.focus_set()
            return
        parsed_date, date_error = validate_reservation_date(date)
        if date_error:
            messagebox.showerror("Invalid Reservation Date", date_error)
            return
        date = parsed_date.strftime("%m/%d/%Y")
        valid_time, time_error = validate_reservation_time(time)
        if time_error:
            messagebox.showerror("Invalid Reservation Time", time_error)
            time_entry.focus_set()
            return
        time = valid_time
        try:
            guests = int(guests)
            if guests <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Number", "Guests must be > 0")
            return

        price = packages[occasion][package]
        is_discounted = False
        if discount_code == DISCOUNT_CODE:
            price = price * (1 - DISCOUNT_PERCENT / 100)
            is_discounted = True
        elif discount_code != "":
            messagebox.showerror("Invalid Code", f"Code '{discount_code}' is invalid. Use {DISCOUNT_CODE}")
            return

        conflict = reservation_conflict(date, time)
        if conflict:
            messagebox.showerror("Schedule Conflict", f"That date and time is already booked by {conflict[1]}.")
            return
        try:
            paid, payment_status = calculate_payment(price)
        except ValueError as e:
            messagebox.showerror("Invalid Payment", str(e))
            return

        db_cursor.execute(
            "INSERT INTO reservations (name, contact, occasion, package, date, time, guests, price, discounted, amount_paid, payment_status) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (name, contact, occasion, package, date, time, guests, price, int(is_discounted), paid, payment_status)
        )
        db_conn.commit()

        load_reservations_from_db()
        update_table()
        update_dashboard()
        clear_fields()
        messagebox.showinfo("Success", f"Reservation Successful!\n{occasion} - {package}\nTotal: ₱{price:,.0f} {'(with 20% OFF)' if is_discounted else ''}")

    def update_table():
        for item in reservation_table.get_children():
            reservation_table.delete(item)
        for r in reservations:
            tag = "discount" if r.get("discounted") else ""
            balance = max(0, r["price"] - r.get("amount_paid", 0))
            reservation_table.insert("", tk.END, values=(r["id"], r["name"], r["contact"], r["occasion"], r["package"], r["date"], r["time"], r["guests"], f"₱{r['price']:,.0f}", f"₱{r.get('amount_paid',0):,.0f}", f"₱{balance:,.0f}", r.get("payment_status", "Unpaid")), tags=(tag,))
        reservation_table.tag_configure("discount", background="#E8F5E9", foreground="#2E7D32")

    def add_payment_to_selected():
        """Add a new payment to the selected reservation without replacing previous payments."""
        selected = reservation_table.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Select a reservation first.")
            return

        reservation_id = int(reservation_table.item(selected[0], "values")[0])
        r = next((res for res in reservations if res["id"] == reservation_id), None)
        if not r:
            messagebox.showerror("Error", "Reservation not found.")
            return

        total = float(r["price"])
        already_paid = float(r.get("amount_paid", 0) or 0)
        balance = max(0, total - already_paid)

        if balance <= 0:
            messagebox.showinfo("Payment Complete", "This reservation is already fully paid.")
            return

        amount = simpledialog.askfloat(
            "Add Payment",
            f"Current paid: ₱{already_paid:,.2f}\nRemaining balance: ₱{balance:,.2f}\n\nEnter the new payment amount:",
            minvalue=0.01,
            maxvalue=balance,
            parent=window
        )
        if amount is None:
            return

        new_paid = already_paid + float(amount)
        if new_paid >= total:
            status = "Paid"
            new_paid = total
        else:
            status = "Partial"

        db_cursor.execute(
            "UPDATE reservations SET amount_paid=?, payment_status=? WHERE id=?",
            (new_paid, status, reservation_id)
        )
        db_conn.commit()
        load_reservations_from_db()
        update_table()
        update_dashboard()

        messagebox.showinfo(
            "Payment Added",
            f"Payment added successfully!\n\nAdded today: ₱{amount:,.2f}\nTotal paid: ₱{new_paid:,.2f}\nRemaining balance: ₱{max(0, total-new_paid):,.2f}\nStatus: {status}"
        )

    def cancel_reservation():
        selected = reservation_table.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Select a reservation first.")
            return
        values = reservation_table.item(selected[0], "values")
        reservation_id = int(values[0])
        if messagebox.askyesno("Cancel", f"Cancel reservation for {values[1]}?"):
            db_cursor.execute("DELETE FROM reservations WHERE id = ?", (reservation_id,))
            db_conn.commit()
            load_reservations_from_db()
            update_table()
            update_dashboard()

    # ------------------- Receipt (Word doc / text) -------------------
    def _write_receipt_docx(r, file_path):
        document = docx.Document()
        document.add_heading("EVENTEASE PRO", level=1)
        document.add_paragraph("Official Reservation Receipt")

        table = document.add_table(rows=0, cols=2)
        table.style = "Light Grid Accent 1"
        rows = [
            ("Receipt No.", str(r["id"])),
            ("Customer Name", r["name"]),
            ("Contact Number", r["contact"]),
            ("Occasion", r["occasion"]),
            ("Package", r["package"]),
            ("Date", r["date"]),
            ("Time", r["time"]),
            ("Guests", str(r["guests"])),
            ("Discount Applied", f"Yes ({DISCOUNT_PERCENT}% OFF)" if r["discounted"] else "No"),
            ("Total Price", f"₱{r['price']:,.2f}"),
            ("Amount Paid", f"₱{r.get('amount_paid',0):,.2f}"),
            ("Balance", f"₱{max(0,r['price']-r.get('amount_paid',0)):,.2f}"),
            ("Payment Status", r.get("payment_status", "Unpaid")),
        ]
        for label, value in rows:
            cells = table.add_row().cells
            cells[0].text = label
            cells[1].text = value

        document.add_paragraph("")
        document.add_paragraph("Thank you for booking with EventEase Pro!")
        document.save(file_path)

    def _write_receipt_txt(r, file_path):
        lines = [
            "==========================================",
            "        EVENTEASE PRO - RECEIPT",
            "==========================================",
            f"Receipt No.:      {r['id']}",
            f"Customer Name:    {r['name']}",
            f"Contact Number:   {r['contact']}",
            f"Occasion:         {r['occasion']}",
            f"Package:          {r['package']}",
            f"Date:             {r['date']}",
            f"Time:             {r['time']}",
            f"Guests:           {r['guests']}",
            f"Discount Applied: {'Yes (' + str(DISCOUNT_PERCENT) + '% OFF)' if r['discounted'] else 'No'}",
            f"Total Price:      ₱{r['price']:,.2f}",
            f"Amount Paid:      ₱{r.get('amount_paid',0):,.2f}",
            f"Balance:          ₱{max(0,r['price']-r.get('amount_paid',0)):,.2f}",
            f"Payment Status:   {r.get('payment_status','Unpaid')}",
            "==========================================",
            "  Thank you for booking with EventEase Pro!",
            "==========================================",
        ]
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def print_receipt():
        selected = reservation_table.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Select a reservation to generate a receipt for.")
            return

        values = reservation_table.item(selected[0], "values")
        reservation_id = int(values[0])
        r = next((res for res in reservations if res["id"] == reservation_id), None)
        if r is None:
            messagebox.showerror("Error", "Reservation not found.")
            return

        safe_name = r["name"].replace(" ", "_")
        if docx is not None:
            file_path = filedialog.asksaveasfilename(
                title="Save Receipt",
                initialfile=f"Receipt_{safe_name}_{r['id']}",
                defaultextension=".docx",
                filetypes=[("Word Document", "*.docx"), ("Text File", "*.txt")]
            )
        else:
            file_path = filedialog.asksaveasfilename(
                title="Save Receipt (install python-docx for Word format)",
                initialfile=f"Receipt_{safe_name}_{r['id']}",
                defaultextension=".txt",
                filetypes=[("Text File", "*.txt")]
            )

        if not file_path:
            return

        try:
            if file_path.lower().endswith(".docx") and docx is not None:
                _write_receipt_docx(r, file_path)
            else:
                _write_receipt_txt(r, file_path)
            messagebox.showinfo("Receipt Saved", f"Receipt saved to:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save receipt:\n{e}")

    # ------------------- Export full list to spreadsheet (CSV) -------------------
    def export_to_spreadsheet():
        if not reservations:
            messagebox.showwarning("No Data", "There are no reservations to export yet.")
            return

        file_path = filedialog.asksaveasfilename(
            title="Export Reservations to Spreadsheet",
            initialfile="reservations_export",
            defaultextension=".csv",
            filetypes=[("CSV Spreadsheet (opens in Excel)", "*.csv")]
        )
        if not file_path:
            return

        try:
            with open(file_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["No.", "Name", "Contact", "Occasion", "Package", "Date", "Time", "Guests", "Discounted", "Total Price", "Amount Paid", "Balance", "Payment Status"])
                for r in reservations:
                    writer.writerow([
                        r["id"], r["name"], r["contact"], r["occasion"], r["package"],
                        r["date"], r["time"], r["guests"],
                        "Yes" if r["discounted"] else "No", f"{r['price']:.2f}",
                        f"{r.get('amount_paid',0):.2f}", f"{max(0,r['price']-r.get('amount_paid',0)):.2f}", r.get("payment_status", "Unpaid")
                    ])
            messagebox.showinfo("Export Complete", f"Reservations exported to:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not export reservations:\n{e}")

    def search_reservations(*_args):
        query = search_entry.get().strip().lower()
        if query == "search name/contact/occasion...":
            query = ""
        for item in reservation_table.get_children():
            reservation_table.delete(item)
        for r in reservations:
            haystack = f"{r['name']} {r['contact']} {r['occasion']} {r['package']} {r['date']} {r['payment_status']}".lower()
            occasion_filter = filter_occasion.get()
            status_filter = filter_status.get()
            matches_occasion = occasion_filter == "All Occasions" or r["occasion"] == occasion_filter
            matches_status = status_filter == "All Status" or r.get("payment_status", "Unpaid") == status_filter
            if query in haystack and matches_occasion and matches_status:
                balance = max(0, r["price"] - r.get("amount_paid", 0))
                tag = "discount" if r.get("discounted") else ""
                reservation_table.insert("", tk.END, values=(r["id"], r["name"], r["contact"], r["occasion"], r["package"], r["date"], r["time"], r["guests"], f"₱{r['price']:,.0f}", f"₱{r.get('amount_paid',0):,.0f}", f"₱{balance:,.0f}", r.get("payment_status", "Unpaid")), tags=(tag,))

    def show_reports():
        report = tk.Toplevel(window)
        report.title("EventEase Reports")
        report.geometry("700x560")
        report.configure(bg="white")
        tk.Label(report, text="EVENTEASE REPORTS", font=("Segoe UI", 18, "bold"), bg="white", fg=COLOR_DARK).pack(pady=(20,5))
        total = sum(r["price"] for r in reservations); paid = sum(r.get("amount_paid",0) for r in reservations); balance = max(0, total-paid)
        tk.Label(report, text=f"Total Reservations: {len(reservations)}", font=("Segoe UI", 11), bg="white").pack(anchor="w", padx=30, pady=5)
        tk.Label(report, text=f"Total Revenue: ₱{total:,.2f}", font=("Segoe UI", 11), bg="white").pack(anchor="w", padx=30, pady=5)
        tk.Label(report, text=f"Amount Paid: ₱{paid:,.2f}", font=("Segoe UI", 11), bg="white").pack(anchor="w", padx=30, pady=5)
        tk.Label(report, text=f"Remaining Balance: ₱{balance:,.2f}", font=("Segoe UI", 11, "bold"), bg="white", fg=COLOR_DANGER).pack(anchor="w", padx=30, pady=5)
        tk.Label(report, text="Payment Status", font=("Segoe UI", 12, "bold"), bg="white", fg=COLOR_DARK).pack(anchor="w", padx=30, pady=(20,5))
        for status in ["Paid", "Partial", "Unpaid"]:
            count = sum(1 for r in reservations if r.get("payment_status") == status)
            tk.Label(report, text=f"{status}: {count}", font=("Segoe UI", 10), bg="white").pack(anchor="w", padx=50, pady=2)
        close_btn = tk.Button(report, text="CLOSE", command=report.destroy, bg=COLOR_ACCENT, fg="white", relief="flat", width=15)
        close_btn.pack(pady=25)

    def update_dashboard():
        total_rev = sum(r["price"] for r in reservations)
        total_guests = sum(r["guests"] for r in reservations)
        count_label.config(text=str(len(reservations)))
        revenue_label.config(text=f"₱{total_rev:,.0f}")
        guests_count_label.config(text=str(total_guests))
        upcoming_count_label.config(text=str(len(upcoming_events(7))))
        paid_count_label.config(text=str(sum(1 for r in reservations if r.get("payment_status") == "Paid")))
        balance_label.config(text=f"₱{sum(max(0, r["price"] - r.get("amount_paid",0)) for r in reservations):,.0f}")
        update_chart()

    def update_chart():
        chart_canvas.delete("all")
        canvas_w = int(chart_canvas["width"])
        canvas_h = int(chart_canvas["height"])

        occasion_names = list(packages.keys())
        counts = {name: 0 for name in occasion_names}
        for r in reservations:
            if r["occasion"] in counts:
                counts[r["occasion"]] += 1

        total_bookings = sum(counts.values())
        max_count = max(counts.values()) if counts.values() else 0
        max_count = max(max_count, 1)  # avoid divide-by-zero when everything is 0

        bar_colors = ["#2878F0", "#D64545", "#00A86B", "#9B59B6", "#F5A623"]
        padding_left = 40
        padding_bottom = 34
        padding_top = 15
        chart_area_h = canvas_h - padding_bottom - padding_top
        chart_area_w = canvas_w - padding_left - 20

        # Soft horizontal gridlines for a cleaner, more polished feel
        grid_lines = 4
        for g in range(grid_lines + 1):
            gy = padding_top + (chart_area_h / grid_lines) * g
            chart_canvas.create_line(
                padding_left, gy, canvas_w - 10, gy,
                fill="#F0F2F5", width=1
            )

        if total_bookings == 0:
            chart_canvas.create_text(
                canvas_w / 2, canvas_h / 2 - 5,
                text="No bookings yet — your first reservation will show up here.",
                font=("Segoe UI", 10), fill=COLOR_MUTED
            )

        n = len(occasion_names)
        slot_w = chart_area_w / n if n else 0
        bar_w = min(slot_w * 0.5, 60)

        # baseline (drawn on top of gridlines so it reads clearly)
        chart_canvas.create_line(
            padding_left, canvas_h - padding_bottom,
            canvas_w - 10, canvas_h - padding_bottom,
            fill="#D9DEE7", width=1
        )

        for i, name in enumerate(occasion_names):
            count = counts[name]
            bar_h = (count / max_count) * chart_area_h if max_count else 0
            x_center = padding_left + slot_w * i + slot_w / 2
            x0 = x_center - bar_w / 2
            x1 = x_center + bar_w / 2
            y1 = canvas_h - padding_bottom
            y0 = y1 - bar_h

            color = bar_colors[i % len(bar_colors)]

            if bar_h > 0:
                radius = min(bar_w / 2, 8)
                # rounded-top bar: a rectangle with a rounded cap drawn via an oval + rect overlap
                chart_canvas.create_rectangle(x0, y0 + radius, x1, y1, fill=color, outline="")
                chart_canvas.create_oval(x0, y0, x1, y0 + radius * 2, fill=color, outline="")

            # subtle backdrop column so empty bars still show their "track"
            chart_canvas.create_rectangle(
                x0, padding_top, x1, y1, fill="", outline=""
            )

            # count label above the bar
            if count > 0:
                chart_canvas.create_text(
                    x_center, y0 - 12, text=str(count),
                    font=("Segoe UI", 10, "bold"), fill=COLOR_DARK
                )

            # Occasion legend: keep the color dot BESIDE the label, not above it.
            # This keeps the chart area clean and makes the occasion names easier to read.
            legend_y = canvas_h - padding_bottom + 16

            # Wrap long occasion names into at most two short lines.
            label = name
            if len(label) > 12:
                words = label.split()
                line1, line2 = "", ""
                for word in words:
                    test = (line1 + " " + word).strip()
                    if not line1 or len(test) <= 11:
                        line1 = test
                    else:
                        line2 = (line2 + " " + word).strip()
                label = line1 + ("\n" + line2 if line2 else "")

            # Dot is placed on the left side of each label.
            label_width = max(30, len(max(label.split("\n"), key=len)) * 4.2)
            dot_x = x_center - (label_width / 2) - 7
            chart_canvas.create_oval(
                dot_x - 4, legend_y - 4, dot_x + 4, legend_y + 4,
                fill=color, outline=""
            )

            chart_canvas.create_text(
                x_center, legend_y, text=label,
                font=("Segoe UI", 7, "bold"), fill=COLOR_MUTED,
                anchor="w", justify="left"
            )

    def generate_qr():
        qr_data = f"EVENTEASE DISCOUNT\nCode: {DISCOUNT_CODE}\nGet {DISCOUNT_PERCENT}% OFF on any package!\nScan to claim at counter."
        # qrcode/Pillow are optional. If either is unavailable, return None
        # instead of crashing the whole application during startup.
        if qrcode is None or Image is None or ImageTk is None:
            return None
        try:
            qr = qrcode.QRCode(version=1, box_size=6, border=2)
            qr.add_data(qr_data)
            qr.make(fit=True)
            img = qr.make_image(fill_color=COLOR_DARK, back_color="white").resize((150, 150))
            return ImageTk.PhotoImage(img)
        except Exception:
            return None

    def add_placeholder(entry, text):
        entry.insert(0, text)
        entry.config(fg="#98A2B3")

        def focus_in(event):
            if entry.get() == text:
                entry.delete(0, tk.END)
                entry.config(fg="#101828")

        def focus_out(event):
            if entry.get().strip() == "":
                entry.insert(0, text)
                entry.config(fg="#98A2B3")

        entry.bind("<FocusIn>", focus_in)
        entry.bind("<FocusOut>", focus_out)

    # ==========================================
    # EVENTEASE EXTRA FEATURES
    # ==========================================
    def parse_event_date(value):
        for fmt in ("%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(str(value).strip(), fmt).date()
            except ValueError:
                pass
        return None

    def upcoming_events(days=7):
        today = date.today()
        end_day = today + timedelta(days=days)
        result = []
        for r in reservations:
            d = parse_event_date(r.get("date", ""))
            if d and today <= d <= end_day:
                result.append((d, r))
        return sorted(result, key=lambda x: (x[0], x[1].get("time", "")))

    def show_upcoming_events():
        win = tk.Toplevel(window)
        win.title("EventEase - Upcoming Events")
        win.geometry("760x560")
        win.configure(bg=COLOR_BG)
        tk.Label(win, text="🔔 Upcoming Events", font=("Segoe UI", 16, "bold"), bg=COLOR_BG, fg=COLOR_DARK).pack(anchor="w", padx=25, pady=(20, 4))
        tk.Label(win, text="Events scheduled for today through the next 7 days", font=("Segoe UI", 10), bg=COLOR_BG, fg=COLOR_MUTED).pack(anchor="w", padx=25, pady=(0,15))
        box=tk.Frame(win,bg="white",highlightbackground="#E5E7EB",highlightthickness=1); box.pack(fill="both",expand=True,padx=25,pady=(0,20))
        items=upcoming_events(7)
        if not items:
            tk.Label(box,text="🎉 No upcoming events in the next 7 days",font=("Segoe UI",14,"bold"),bg="white",fg=COLOR_MUTED).pack(expand=True)
        else:
            for d,r in items:
                row=tk.Frame(box,bg="white"); row.pack(fill="x",padx=18,pady=10)
                tk.Label(row,text=d.strftime("%b %d"),font=("Segoe UI",15,"bold"),bg="white",fg=COLOR_ACCENT,width=8).pack(side="left")
                tk.Label(row,text=f"{r['name']} • {r['occasion']}",font=("Segoe UI",11,"bold"),bg="white",fg=COLOR_DARK).pack(side="left",anchor="w")
                tk.Label(row,text=f"{r['date']}  {r['time']}\n{r['package']} • {r['guests']} guests",font=("Segoe UI",9),bg="white",fg=COLOR_MUTED,justify="left").pack(side="right",anchor="e")
        tk.Button(win,text="CLOSE",command=win.destroy,bg=COLOR_ACCENT,fg="white",relief="flat",width=15).pack(pady=(0,18))

    def show_calendar_view():
        win=tk.Toplevel(window); win.title("EventEase - Booked Events Calendar"); win.geometry("1050x760"); win.configure(bg=COLOR_BG)
        state=[date.today().year,date.today().month]
        title=tk.Label(win,text="",font=("Segoe UI",20,"bold"),bg=COLOR_BG,fg=COLOR_DARK); title.pack(pady=(18,4))
        subtitle=tk.Label(win,text="Booked events are shown directly on their reservation dates",font=("Segoe UI",10),bg=COLOR_BG,fg=COLOR_MUTED); subtitle.pack()
        grid=tk.Frame(win,bg="white",highlightbackground="#E5E7EB",highlightthickness=1); grid.pack(fill="both",expand=True,padx=25,pady=10)
        details=tk.Label(win,text="Click a booked event to see its customer, time, package and guests.",font=("Segoe UI",10),bg=COLOR_BG,fg=COLOR_MUTED,justify="left",anchor="w"); details.pack(fill="x",padx=30,pady=(0,10))

        def show_event(r):
            details.config(text=f"BOOKED: {r.get('occasion','Event')}  |  Customer: {r.get('name','')}  |  Date: {r.get('date','')}  |  Time: {r.get('time','')}  |  Package: {r.get('package','')}  |  Guests: {r.get('guests','')}")

        def render():
            for w in grid.winfo_children(): w.destroy()
            y,m=state; title.config(text=f"📅 {pycalendar.month_name[m]} {y}")
            nav=tk.Frame(grid,bg="white"); nav.grid(row=0,column=0,columnspan=7,sticky="ew",pady=10)
            tk.Button(nav,text="‹",font=("Segoe UI",14,"bold"),command=lambda:change(-1),bg="white",relief="flat").pack(side="left",padx=20)
            tk.Button(nav,text="Today",command=lambda:today_view(),bg="#EEF4FF",fg=COLOR_ACCENT,relief="flat").pack(side="left")
            tk.Button(nav,text="›",font=("Segoe UI",14,"bold"),command=lambda:change(1),bg="white",relief="flat").pack(side="right",padx=20)
            names=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
            for cc,n in enumerate(names): tk.Label(grid,text=n,font=("Segoe UI",9,"bold"),bg="#F4F6F8",fg=COLOR_MUTED,pady=8).grid(row=1,column=cc,sticky="nsew",padx=1,pady=1)
            events={}
            for r in reservations:
                d=parse_event_date(r.get("date",""))
                if d and d.year==y and d.month==m: events.setdefault(d.day,[]).append(r)
            weeks=pycalendar.monthcalendar(y,m)
            for rr,week in enumerate(weeks,2):
                for cc,daynum in enumerate(week):
                    cell=tk.Frame(grid,bg="white",height=95); cell.grid(row=rr,column=cc,sticky="nsew",padx=1,pady=1); cell.grid_propagate(False)
                    if daynum:
                        day_events=events.get(daynum,[])
                        bg="#EAF2FF" if date(y,m,daynum)==date.today() else "white"
                        tk.Label(cell,text=str(daynum),font=("Segoe UI",10,"bold"),bg=bg,fg=COLOR_DARK).pack(anchor="nw",padx=6,pady=4)
                        if day_events:
                            for r in day_events[:3]:
                                event_text=f"{r.get('time','')} • {r.get('occasion','Event')}"
                                b=tk.Button(cell,text=event_text,font=("Segoe UI",7,"bold"),bg="#DDEBFF",fg=COLOR_DARK,activebackground="#C9DDFF",relief="flat",anchor="w",command=lambda rr=r:show_event(rr))
                                b.pack(fill="x",padx=4,pady=1)
                            if len(day_events)>3: tk.Label(cell,text=f"+{len(day_events)-3} more booked",font=("Segoe UI",7),bg=bg,fg=COLOR_MUTED).pack(anchor="w",padx=5)
                        else:
                            tk.Label(cell,text="No booking",font=("Segoe UI",7),bg=bg,fg="#A0A7B0").pack(anchor="w",padx=5,pady=2)
            for cc in range(7): grid.grid_columnconfigure(cc,weight=1)
            for rr in range(2,2+len(weeks)): grid.grid_rowconfigure(rr,weight=1)
        def change(delta):
            m=state[1]+delta; y=state[0]
            if m<1: m=12;y-=1
            if m>12: m=1;y+=1
            state[:]=[y,m]; render()
        def today_view(): state[:]=[date.today().year,date.today().month]; render()
        render()
        tk.Button(win,text="CLOSE",command=win.destroy,bg=COLOR_ACCENT,fg="white",relief="flat",width=15).pack(pady=(0,18))

    def show_gallery():
        win=tk.Toplevel(window); win.title("EventEase - Event Gallery"); win.geometry("900x650"); win.configure(bg=COLOR_BG)
        tk.Label(win,text="🖼️ Event Gallery",font=("Segoe UI",20,"bold"),bg=COLOR_BG,fg=COLOR_DARK).pack(anchor="w",padx=25,pady=(20,4))
        tk.Label(win,text="Choose an occasion to preview its event style",font=("Segoe UI",10),bg=COLOR_BG,fg=COLOR_MUTED).pack(anchor="w",padx=25,pady=(0,12))
        top=tk.Frame(win,bg=COLOR_BG); top.pack(fill="x",padx=25)
        combo=ttk.Combobox(top,state="readonly",values=list(packages.keys()),width=28); combo.pack(side="left")
        combo.set(occasion_combo.get() if occasion_combo.get() in packages else list(packages.keys())[0])
        canvas=tk.Canvas(win,bg="white",highlightthickness=0,height=430); canvas.pack(fill="both",expand=True,padx=25,pady=15)
        designs={"Birthday":("#FF6B8A","#FFC371","🎂"),"Wedding":("#9B7EDE","#F6C7D7","💍"),"Graduation":("#2878F0","#63D2FF","🎓"),"Baby Shower":("#65B7E8","#B8E8FF","🍼"),"Debut":("#B45FC8","#F3A7D5","🎉"),"Christmas Party":("#238636","#E85D75","🎄")}
        def render(*_):
            canvas.delete("all"); name=combo.get(); c1,c2,icon=designs.get(name,("#2878F0","#63D2FF","✨")); w=max(canvas.winfo_width(),800)
            canvas.create_rectangle(0,0,w,430,fill=c1,outline=c1); canvas.create_oval(w-260,-80,w+80,260,fill=c2,outline=""); canvas.create_oval(-90,300,180,570,fill=c2,outline="")
            canvas.create_text(w/2,135,text=icon,font=("Segoe UI Emoji",58),fill="white")
            canvas.create_text(w/2,225,text=name.upper(),font=("Segoe UI",30,"bold"),fill="white")
            canvas.create_text(w/2,270,text="Beautiful moments. Memorable events. EventEase.",font=("Segoe UI",12,"bold"),fill="white")
        combo.bind("<<ComboboxSelected>>",render); canvas.bind("<Configure>",render); render()
        tk.Button(win,text="CLOSE",command=win.destroy,bg=COLOR_ACCENT,fg="white",relief="flat",width=15).pack(pady=(0,18))

    def show_package_comparison():
        win=tk.Toplevel(window); win.title("EventEase - Package Comparison"); win.geometry("850x560"); win.configure(bg=COLOR_BG)
        tk.Label(win,text="⭐ Package Comparison",font=("Segoe UI",20,"bold"),bg=COLOR_BG,fg=COLOR_DARK).pack(anchor="w",padx=25,pady=(20,5))
        combo=ttk.Combobox(win,state="readonly",values=list(packages.keys()),width=30); combo.pack(anchor="w",padx=25,pady=8); combo.set(occasion_combo.get() if occasion_combo.get() in packages else list(packages.keys())[0])
        table=tk.Frame(win,bg="white",highlightbackground="#E5E7EB",highlightthickness=1); table.pack(fill="both",expand=True,padx=25,pady=12)
        def render(*_):
            for w in table.winfo_children(): w.destroy()
            name=combo.get(); data=packages[name]
            tk.Label(table,text=name,font=("Segoe UI",17,"bold"),bg="white",fg=COLOR_DARK).grid(row=0,column=0,columnspan=3,pady=18)
            for c,pkg in enumerate(["Basic","Premium","Deluxe"]):
                tk.Label(table,text=pkg,font=("Segoe UI",12,"bold"),bg="#EEF4FF",fg=COLOR_ACCENT,width=24,pady=10).grid(row=1,column=c,padx=4,pady=4)
                tk.Label(table,text=f"₱{data[pkg]:,.0f}",font=("Segoe UI",20,"bold"),bg="white",fg=COLOR_DARK,pady=15).grid(row=2,column=c)
                desc={"Basic":"Essential event setup","Premium":"Enhanced styling + extras","Deluxe":"Full premium experience"}[pkg]
                tk.Label(table,text=desc,font=("Segoe UI",10),bg="white",fg=COLOR_MUTED,pady=10).grid(row=3,column=c)
            for c in range(3): table.grid_columnconfigure(c,weight=1)
        combo.bind("<<ComboboxSelected>>",render); render()
        tk.Button(win,text="CLOSE",command=win.destroy,bg=COLOR_ACCENT,fg="white",relief="flat",width=15).pack(pady=(0,18))

    def show_customer_profile():
        selected=reservation_table.selection()
        if not selected:
            messagebox.showwarning("No Selection","Select a reservation to view the customer profile."); return
        rid=int(reservation_table.item(selected[0],"values")[0]); r=next((x for x in reservations if x["id"]==rid),None)
        if not r: return
        history=[x for x in reservations if x["name"].strip().lower()==r["name"].strip().lower() or x["contact"].strip()==r["contact"].strip()]
        total=sum(x["price"] for x in history); paid=sum(x.get("amount_paid",0) for x in history)
        win=tk.Toplevel(window); win.title("EventEase - Customer Profile"); win.geometry("620x560"); win.configure(bg=COLOR_BG)
        tk.Label(win,text="👤 Customer Profile",font=("Segoe UI",20,"bold"),bg=COLOR_BG,fg=COLOR_DARK).pack(anchor="w",padx=25,pady=(20,12))
        card=tk.Frame(win,bg="white",highlightbackground="#E5E7EB",highlightthickness=1); card.pack(fill="both",expand=True,padx=25,pady=(0,20))
        info=[("Customer",r["name"]),("Contact",r["contact"]),("Bookings",str(len(history))),("Total Booked",f"₱{total:,.2f}"),("Total Paid",f"₱{paid:,.2f}"),("Balance",f"₱{max(0,total-paid):,.2f}")]
        for i,(a,b) in enumerate(info):
            tk.Label(card,text=a,font=("Segoe UI",9,"bold"),bg="white",fg=COLOR_MUTED).grid(row=i,column=0,sticky="w",padx=25,pady=(15,2)); tk.Label(card,text=b,font=("Segoe UI",12,"bold"),bg="white",fg=COLOR_DARK).grid(row=i,column=1,sticky="w",padx=25,pady=(15,2))
        tk.Label(card,text="Booking History",font=("Segoe UI",12,"bold"),bg="white",fg=COLOR_DARK).grid(row=7,column=0,columnspan=2,sticky="w",padx=25,pady=(20,8))
        for j,x in enumerate(history[:8],8): tk.Label(card,text=f"{x['date']} • {x['occasion']} • {x['package']} • ₱{x['price']:,.0f}",font=("Segoe UI",9),bg="white",fg=COLOR_MUTED).grid(row=j,column=0,columnspan=2,sticky="w",padx=25,pady=2)
        tk.Button(win,text="CLOSE",command=win.destroy,bg=COLOR_ACCENT,fg="white",relief="flat",width=15).pack(pady=(0,18))

    def backup_database():
        target=filedialog.asksaveasfilename(title="Backup EventEase Database",initialfile=f"EventEase_Backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db",defaultextension=".db",filetypes=[("SQLite Database","*.db")])
        if not target: return
        try:
            db_conn.commit(); shutil.copy2(DB_PATH,target); messagebox.showinfo("Backup Complete",f"Database backup saved to:\n{target}")
        except Exception as e: messagebox.showerror("Backup Error",str(e))

    # ------------------------------------------
    # MAIN WINDOW
    # ------------------------------------------
    window = tk.Tk()

    window.title("EventEase Pro - with QR Discount")
    window.geometry("1720x900")
    window.minsize(1300, 750)
    window.configure(bg=COLOR_BG)

    # --- SIDEBAR ---
    sidebar = tk.Frame(window, bg=COLOR_DARK, width=260)
    sidebar.pack(side="left", fill="y")

    header_block = tk.Frame(sidebar, bg=COLOR_DARK)
    header_block.pack(pady=(35, 15), padx=20, fill="x")

    logo_widget = build_logo_widget(header_block, box_bg=COLOR_DARK)
    logo_widget.pack(anchor="w")

    tk.Label(header_block, text="EVENTEASE", font=("Segoe UI", 24, "bold"), fg="white", bg=COLOR_DARK, justify="left").pack(anchor="w", pady=(10, 2))
    tk.Label(header_block, text="PRO EDITION • 2026", font=("Segoe UI", 8, "bold"), fg=COLOR_ACCENT, bg=COLOR_DARK).pack(anchor="w")

    # --- SIDEBAR NAVIGATION ---
    dash_frame = tk.Frame(sidebar, bg=COLOR_DARK)
    dash_frame.pack(pady=(20, 10), padx=15, fill="x")

    tk.Label(
        dash_frame,
        text="NAVIGATION",
        font=("Segoe UI", 8, "bold"),
        fg="#9AA5B8",
        bg=COLOR_DARK
    ).pack(anchor="w", pady=(0, 8))

    create_nav_btn = tk.Button(
        dash_frame,
        text="📝  CREATE RESERVATION",
        bg=COLOR_ACCENT,
        fg="white",
        activebackground=COLOR_ACCENT_HOVER,
        activeforeground="white",
        font=("Segoe UI", 10, "bold"),
        relief="flat",
        bd=0,
        height=2,
        cursor="hand2"
    )
    create_nav_btn.pack(fill="x", pady=4)
    add_hover(create_nav_btn, COLOR_ACCENT, COLOR_ACCENT_HOVER)

    list_nav_btn = tk.Button(
        dash_frame,
        text="📋  RESERVATION LIST",
        bg="#22304A",
        fg="white",
        activebackground="#2E3F5E",
        activeforeground="white",
        font=("Segoe UI", 10, "bold"),
        relief="flat",
        bd=0,
        height=2,
        cursor="hand2"
    )
    list_nav_btn.pack(fill="x", pady=4)
    add_hover(list_nav_btn, "#22304A", "#2E3F5E")

    # QR CODE AREA
    qr_container = tk.Frame(sidebar, bg="white", highlightbackground="#E0E0E0", highlightthickness=1)
    qr_container.pack(pady=20, padx=15, fill="x")

    tk.Label(qr_container, text="SCAN FOR DISCOUNT", font=("Segoe UI", 8, "bold"), bg="white", fg=COLOR_DANGER).pack(pady=(12, 2))
    qr_photo = generate_qr()
    if qr_photo is not None:
        qr_label = tk.Label(qr_container, image=qr_photo, bg="white")
        qr_label.image = qr_photo
        qr_label.pack(pady=5)
    else:
        tk.Label(
            qr_container,
            text="QR preview unavailable\nInstall: pip install qrcode[pil]",
            font=("Segoe UI", 8, "bold"),
            bg="white", fg=COLOR_MUTED, justify="center",
            height=6
        ).pack(pady=5)

    tk.Label(qr_container, text=f"Code: {DISCOUNT_CODE}", font=("Consolas", 12, "bold"), bg="white", fg=COLOR_DARK).pack()
    tk.Label(qr_container, text=f"Get {DISCOUNT_PERCENT}% OFF\non any package!", font=("Segoe UI", 8), bg="white", fg=COLOR_MUTED, justify="center").pack(pady=(2, 12))

    def logout():
        if messagebox.askyesno("Logout", "Are you sure you want to log out?"):
            window.destroy()
            show_login_screen()

    logout_btn = tk.Button(sidebar, text="Logout", bg="#22304A", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", command=logout, height=2, cursor="hand2")
    logout_btn.pack(side="bottom", fill="x", padx=15, pady=(0, 10))
    add_hover(logout_btn, "#22304A", "#2E3F5E")

    exit_btn = tk.Button(sidebar, text="Exit System", bg=COLOR_DANGER, fg="white", font=("Segoe UI", 10, "bold"), relief="flat", command=window.destroy, height=2, cursor="hand2")
    exit_btn.pack(side="bottom", fill="x", padx=15, pady=(25, 0))
    add_hover(exit_btn, COLOR_DANGER, COLOR_DANGER_HOVER)

    # --- MAIN CONTENT (scrollable, so nothing ever gets clipped) ---
    main_container = tk.Frame(window, bg=COLOR_BG)
    main_container.pack(side="right", fill="both", expand=True)

    main_canvas_scroll = tk.Canvas(main_container, bg=COLOR_BG, highlightthickness=0)
    main_scrollbar = tk.Scrollbar(main_container, orient="vertical", command=main_canvas_scroll.yview)
    main_canvas_scroll.configure(yscrollcommand=main_scrollbar.set)

    main_scrollbar.pack(side="right", fill="y")
    main_canvas_scroll.pack(side="left", fill="both", expand=True)

    main_frame = tk.Frame(main_canvas_scroll, bg=COLOR_BG)
    main_frame_window = main_canvas_scroll.create_window((0, 0), window=main_frame, anchor="nw")

    def _on_main_frame_configure(_event=None):
        main_canvas_scroll.configure(scrollregion=main_canvas_scroll.bbox("all"))

    def _on_canvas_resize(event):
        main_canvas_scroll.itemconfig(main_frame_window, width=event.width)

    main_frame.bind("<Configure>", _on_main_frame_configure)
    main_canvas_scroll.bind("<Configure>", _on_canvas_resize)

    def _on_mousewheel(event):
        # Keep the main page from moving when the mouse is over a dropdown.
        try:
            if event.widget.winfo_class() == "TCombobox":
                return "break"
        except (tk.TclError, AttributeError):
            pass

        main_canvas_scroll.yview_scroll(int(-1 * (event.delta / 120)), "units")

    main_canvas_scroll.bind_all("<MouseWheel>", _on_mousewheel)

    # --- PROMOTION HEADER ---
    header = tk.Frame(main_frame, bg=COLOR_BG)
    header.pack(fill="x", padx=30, pady=(20, 10))

    title_frame = tk.Frame(header, bg=COLOR_BG)
    title_frame.pack(fill="x", pady=(0, 10))

    tk.Label(title_frame, text="EVENTEASE", font=("Segoe UI", 16, "bold"), fg=COLOR_DARK, bg=COLOR_BG).pack(side="left")
    tk.Label(title_frame, text="  |  RESERVATION • CATERING • EVENT PLANNING", font=("Segoe UI", 8, "bold"), fg=COLOR_ACCENT, bg=COLOR_BG).pack(side="left", pady=(5, 0))

    # DYNAMIC EVENT BANNER
    # The banner changes design whenever the user selects an occasion.
    promo_container = tk.Frame(header, bg="white", highlightbackground="#D9DEE7", highlightthickness=1)
    promo_container.pack(fill="x", expand=True, padx=10)

    event_banner_canvas = tk.Canvas(
        promo_container, height=300, bg="#F7F0FF", bd=0,
        highlightthickness=0, relief="flat"
    )
    event_banner_canvas.pack(fill="x", expand=True)

    # Show the default EventEase design first.
    update_event_banner()

    tk.Label(header, text="Create and manage reservations with exclusive promotional offers.", font=("Segoe UI", 10), fg=COLOR_MUTED, bg=COLOR_BG).pack(anchor="w", pady=(8, 0))

    quick_actions = tk.Frame(header, bg=COLOR_BG)
    quick_actions.pack(fill="x", pady=(10, 0))
    quick_actions.grid_columnconfigure((0, 1, 2), weight=1, uniform="quick")
    quick_calendar = tk.Button(quick_actions, text="📅 Calendar View", command=show_calendar_view, bg=COLOR_DARK, fg="white", relief="flat", font=("Segoe UI", 8, "bold"), height=2, cursor="hand2")
    quick_calendar.grid(row=0, column=0, sticky="ew", padx=(0, 6))
    quick_upcoming = tk.Button(quick_actions, text="🔔 Upcoming Events", command=show_upcoming_events, bg="#9B59B6", fg="white", relief="flat", font=("Segoe UI", 8, "bold"), height=2, cursor="hand2")
    quick_upcoming.grid(row=0, column=1, sticky="ew", padx=3)
    quick_gallery = tk.Button(quick_actions, text="🖼 Event Gallery", command=show_gallery, bg="#2A9D8F", fg="white", relief="flat", font=("Segoe UI", 8, "bold"), height=2, cursor="hand2")
    quick_gallery.grid(row=0, column=2, sticky="ew", padx=(6, 0))
    add_hover(quick_calendar, COLOR_DARK, "#22304A")
    add_hover(quick_upcoming, "#9B59B6", "#81419A")
    add_hover(quick_gallery, "#2A9D8F", "#238574")

    # DASHBOARD STATS
    stats_frame = tk.Frame(main_frame, bg=COLOR_BG)
    stats_frame.pack(fill="x", padx=30, pady=(10, 6))
    stats_frame.grid_propagate(False)

    def stat_card(parent, title, value_text, icon_char, accent_color):
        card = tk.Frame(parent, bg="white", highlightbackground="#E5E7EB", highlightthickness=1)
        card.pack(side="left", fill="x", expand=True, padx=(0, 8))

        # Colored accent strip along the top edge
        tk.Frame(card, bg=accent_color, height=4).pack(fill="x", side="top")

        content_row = tk.Frame(card, bg="white")
        content_row.pack(fill="x", padx=10, pady=(12, 12))

        # Icon badge (tinted circle with an icon/glyph centered inside)
        badge = tk.Canvas(content_row, width=38, height=38, bg="white", highlightthickness=0)
        badge.pack(side="left", padx=(0, 14))
        badge.create_oval(2, 2, 36, 36, outline="", fill=_tint(accent_color, 0.85))
        badge.create_text(19, 19, text=icon_char, font=("Segoe UI Emoji", 15), fill=accent_color)

        text_col = tk.Frame(content_row, bg="white")
        text_col.pack(side="left", fill="both", expand=True)

        tk.Label(text_col, text=title, font=("Segoe UI", 8, "bold"), bg="white", fg="#6B7280").pack(anchor="w")
        lbl = tk.Label(text_col, text=value_text, font=("Segoe UI", 16, "bold"), bg="white", fg=COLOR_DARK)
        lbl.pack(anchor="w", pady=(2, 0))
        return lbl

    count_label = stat_card(stats_frame, "TOTAL BOOKINGS", "0", "📅", COLOR_ACCENT)
    revenue_label = stat_card(stats_frame, "TOTAL REVENUE", "₱0", "₱", COLOR_SUCCESS)
    guests_count_label = stat_card(stats_frame, "TOTAL GUESTS", "0", "👥", "#F5A623")
    upcoming_count_label = stat_card(stats_frame, "UPCOMING (7 DAYS)", "0", "🔔", "#9B59B6")
    paid_count_label = stat_card(stats_frame, "PAID BOOKINGS", "0", "✓", "#00A86B")
    balance_label = stat_card(stats_frame, "TOTAL BALANCE", "₱0", "₱", COLOR_DANGER)

    # MINI ANALYTICS CHART
    chart_card = tk.Frame(main_frame, bg="white", highlightbackground="#DDE7E8", highlightthickness=1)
    chart_card.pack(fill="x", padx=30, pady=(0, 6))

    chart_header = tk.Frame(chart_card, bg="white")
    chart_header.pack(fill="x", padx=20, pady=(15, 5))

    tk.Label(
        chart_header, text="📊", font=("Segoe UI Emoji", 13), bg="white"
    ).pack(side="left", padx=(0, 8))
    tk.Label(
        chart_header, text="Bookings by Occasion", font=("Segoe UI", 12, "bold"),
        bg="white", fg=COLOR_DARK
    ).pack(side="left")
    tk.Label(
        chart_header, text="  •  live overview of your reservations", font=("Segoe UI", 9),
        bg="white", fg=COLOR_MUTED
    ).pack(side="left")

    chart_canvas = tk.Canvas(chart_card, width=1640, height=180, bg="white", highlightthickness=0)
    chart_canvas.pack(padx=20, pady=(0, 12), fill="x")

    # FORM CARD
    form_card = tk.Frame(main_frame, bg="white", highlightbackground="#E5E7EB", highlightthickness=1)
    form_card.pack(fill="x", padx=30, pady=(0, 6))
    for _col in range(5):
        form_card.grid_columnconfigure(_col, weight=1, uniform="formcol")
    for _col in range(4):
        form_card.grid_columnconfigure(_col, weight=1, uniform="form_col")

    tk.Label(form_card, text="Create New Reservation", font=("Segoe UI", 14, "bold"), bg="white", fg=COLOR_DARK).grid(row=0, column=0, columnspan=5, sticky="w", padx=20, pady=(12, 10))

    def create_label(text, r, c):
        tk.Label(form_card, text=text, font=("Segoe UI", 8, "bold"), bg="white", fg="#4B5563").grid(row=r, column=c, sticky="w", padx=(20 if c == 0 else 10, 15), pady=(5, 0))

    name_entry = tk.Entry(form_card, font=("Segoe UI", 11), bd=1, relief="solid")
    contact_entry = tk.Entry(form_card, font=("Segoe UI", 11), bd=1, relief="solid")

    def restrict_contact_input(event=None):
        """Keep the contact field to digits only and a maximum of 11 digits."""
        value = contact_entry.get()
        placeholder = "e.g. 0917 123 4567"
        if value == placeholder:
            return

        digits = "".join(ch for ch in value if ch.isdigit())[:11]
        if digits != value:
            contact_entry.delete(0, tk.END)
            contact_entry.insert(0, digits)
            contact_entry.config(fg=COLOR_DARK)

    contact_entry.bind("<KeyRelease>", restrict_contact_input)

    def restrict_time_input(event=None):
        """Keep time input limited to a reasonable clock-time length."""
        value = time_entry.get()
        if value.lower() == "e.g. 10:00 am":
            return
        # Do not allow an excessively long value; final validation checks the actual time.
        if len(value) > 8:
            time_entry.delete(8, tk.END)

    create_label("Customer Name", 1, 0)
    add_placeholder(name_entry, "Enter customer name")
    name_entry.grid(row=2, column=0, padx=(20, 15), pady=5, sticky="ew")

    create_label("Contact Number", 1, 1)
    add_placeholder(contact_entry, "e.g. 09171234567")

    create_label("Occasion", 1, 2)
    contact_entry.grid(row=2, column=1, padx=(10, 15), pady=5, sticky="ew")
    # Keep Occasion and Package perfectly aligned with the other booking fields.
    combo_style = "EventEase.TCombobox"
    combo_style_obj = ttk.Style()
    try:
        combo_style_obj.configure(combo_style, font=("Segoe UI", 11), padding=(8, 5))
    except Exception:
        pass

    occasion_combo = ttk.Combobox(
        form_card, state="readonly", values=list(packages.keys()), style=combo_style
    )
    occasion_combo.set("Select occasion")
    occasion_combo.grid(row=2, column=2, padx=(10, 15), pady=5, sticky="ew", ipady=2)
    occasion_combo.bind("<<ComboboxSelected>>", update_packages)

    create_label("Package", 1, 3)
    package_combo = ttk.Combobox(form_card, state="readonly", style=combo_style)
    package_combo.set("Select package")
    package_combo.grid(row=2, column=3, padx=(10, 15), pady=5, sticky="ew", ipady=2)
    package_combo.bind("<<ComboboxSelected>>", update_price_preview)

    create_label("Date (MM/DD/YYYY)", 3, 0)
    date_frame = tk.Frame(form_card, bg="white")
    date_frame.grid(row=4, column=0, padx=(20, 15), pady=5, sticky="ew")
    date_frame.grid_columnconfigure(0, weight=1)

    date_entry = tk.Entry(date_frame, font=("Segoe UI", 11), bd=1, relief="solid")
    add_placeholder(date_entry, "mm/dd/yyyy")
    date_entry.grid(row=0, column=0, sticky="ew", ipady=2)

    date_picker_btn = tk.Button(
        date_frame, text="📅", font=("Segoe UI", 11, "bold"), width=4,
        bg=COLOR_ACCENT, fg="white",
        activebackground=COLOR_ACCENT_HOVER, activeforeground="white",
        relief="flat", bd=0, cursor="hand2", command=open_date_picker
    )
    date_picker_btn.grid(row=0, column=1, padx=(5, 0))
    add_hover(date_picker_btn, COLOR_ACCENT, COLOR_ACCENT_HOVER)

    create_label("Time", 3, 1)
    time_entry = tk.Entry(form_card, font=("Segoe UI", 11), bd=1, relief="solid")
    add_placeholder(time_entry, "e.g. 10:00 AM")
    time_entry.grid(row=4, column=1, padx=(10, 15), pady=5, sticky="ew")
    time_entry.bind("<KeyRelease>", restrict_time_input)

    create_label("Guests", 3, 2)
    guests_entry = tk.Entry(form_card, font=("Segoe UI", 11), bd=1, relief="solid")
    add_placeholder(guests_entry, "Number of guests")
    guests_entry.grid(row=4, column=2, padx=(10, 15), pady=5, sticky="ew")

    create_label(f"Discount Code ({DISCOUNT_CODE}=20% OFF)", 3, 3)
    discount_entry = tk.Entry(form_card, font=("Consolas", 11, "bold"), bd=1, relief="solid", fg=COLOR_DANGER)
    discount_entry.grid(row=4, column=3, padx=(10, 15), pady=5, sticky="ew")
    add_placeholder(discount_entry, "Enter discount code")
    discount_entry.bind("<KeyRelease>", update_price_preview)

    create_label("Amount Paid", 5, 0)
    amount_paid_entry = tk.Entry(form_card, font=("Segoe UI", 11), bd=1, relief="solid")
    amount_paid_entry.grid(row=6, column=0, padx=(20, 15), pady=5, sticky="ew")
    add_placeholder(amount_paid_entry, "0.00")

    create_label("Payment Status", 5, 1)
    payment_status_combo = ttk.Combobox(form_card, state="readonly", values=["Unpaid", "Partial", "Paid"])
    payment_status_combo.set("Unpaid")
    payment_status_combo.grid(row=6, column=1, padx=(10, 15), pady=5, sticky="ew")

    price_frame = tk.Frame(form_card, bg="white")
    price_frame.grid(row=7, column=0, columnspan=2, sticky="w", padx=20, pady=10)
    tk.Label(price_frame, text="Total Price:", font=("Segoe UI", 10, "bold"), bg="white").pack(side="left")
    price_label = tk.Label(price_frame, text="₱0", font=("Segoe UI", 14, "bold"), bg="white", fg=COLOR_ACCENT)
    price_label.pack(side="left", padx=10)

    create_btn = tk.Button(form_card, text="CREATE RESERVATION", bg=COLOR_ACCENT, fg="white", font=("Segoe UI", 10, "bold"), relief="flat", height=2, width=22, command=make_reservation, cursor="hand2")
    create_btn.grid(row=7, column=3, padx=20, pady=10, sticky="e")
    add_hover(create_btn, COLOR_ACCENT, COLOR_ACCENT_HOVER)

    clear_btn = tk.Button(form_card, text="CLEAR", bg="#E9EDF2", fg="#4B5563", font=("Segoe UI", 8, "bold"), relief="flat", command=clear_fields, cursor="hand2")
    clear_btn.grid(row=7, column=2, sticky="e", pady=10)
    add_hover(clear_btn, "#E9EDF2", "#D9DEE7")

    # ==========================================
    # SIDEBAR NAVIGATION ACTIONS
    # ==========================================
    def go_to_create_reservation():
        """Scroll to the reservation form and focus the customer name field."""
        try:
            main_canvas_scroll.update_idletasks()
            y = form_card.winfo_y()
            total_height = max(1, main_frame.winfo_height())
            position = max(0.0, min(1.0, y / total_height))
            main_canvas_scroll.yview_moveto(position)
            name_entry.focus_set()
        except (tk.TclError, AttributeError):
            pass

    def go_to_reservation_list():
        """Scroll to the reservation list and focus the search field."""
        try:
            main_canvas_scroll.update_idletasks()
            y = list_header_row.winfo_y()
            total_height = max(1, main_frame.winfo_height())
            position = max(0.0, min(1.0, y / total_height))
            main_canvas_scroll.yview_moveto(position)
            search_entry.focus_set()
        except (tk.TclError, AttributeError):
            pass

    # The buttons are created before the form/list widgets, so assign their
    # commands here after all required widgets already exist.

    # TABLE
    # Two clean toolbar rows prevent button crowding at smaller window sizes.
    list_header_row = tk.Frame(main_frame, bg=COLOR_BG)
    list_header_row.pack(fill="x", padx=30, pady=(8, 4))

    list_header_row.grid_columnconfigure(0, weight=1)
    tk.Label(list_header_row, text="Reservation List - Green rows have discount applied", font=("Segoe UI", 12, "bold"), bg=COLOR_BG, fg=COLOR_DARK).grid(row=0, column=0, sticky="w")

    search_entry = tk.Entry(list_header_row, font=("Segoe UI", 10), width=28, relief="solid")
    search_entry.grid(row=0, column=1, padx=(8, 0), ipady=4, sticky="e")
    search_entry.insert(0, "Search name/contact/occasion...")
    search_entry.config(fg="#98A2B3")
    def _search_focus_in(event):
        if search_entry.get() == "Search name/contact/occasion...":
            search_entry.delete(0, tk.END); search_entry.config(fg=COLOR_DARK)
    def _search_focus_out(event):
        if not search_entry.get().strip():
            search_entry.insert(0, "Search name/contact/occasion..."); search_entry.config(fg="#98A2B3")
    search_entry.bind("<FocusIn>", _search_focus_in)
    search_entry.bind("<FocusOut>", _search_focus_out)
    search_entry.bind("<KeyRelease>", search_reservations)

    filter_occasion = ttk.Combobox(list_header_row, state="readonly", values=["All Occasions"] + list(packages.keys()), width=18)
    filter_occasion.set("All Occasions")
    filter_occasion.grid(row=0, column=2, padx=(8, 0), ipady=2, sticky="e")
    filter_status = ttk.Combobox(list_header_row, state="readonly", values=["All Status", "Paid", "Partial", "Unpaid"], width=12)
    filter_status.set("All Status")
    filter_status.grid(row=0, column=3, padx=(8, 0), ipady=2, sticky="e")
    filter_occasion.bind("<<ComboboxSelected>>", search_reservations)
    filter_status.bind("<<ComboboxSelected>>", search_reservations)

    list_action_row = tk.Frame(main_frame, bg=COLOR_BG)
    list_action_row.pack(fill="x", padx=30, pady=(0, 6))

    action_buttons = []
    def make_list_action(text, command, bg="white", fg=COLOR_DARK):
        btn = tk.Button(list_action_row, text=text, bg=bg, fg=fg, font=("Segoe UI", 8, "bold"), relief="flat", height=2, padx=8, command=command, cursor="hand2", bd=1, highlightbackground="#D9DEE7", highlightthickness=1)
        btn.pack(side="left", padx=(0, 6))
        action_buttons.append(btn)
        return btn

    report_btn = make_list_action("📊 Reports", show_reports)
    calendar_btn = make_list_action("📅 Calendar", show_calendar_view)
    upcoming_btn = make_list_action("🔔 Upcoming", show_upcoming_events)
    package_btn = make_list_action("⭐ Packages", show_package_comparison)
    customer_btn = make_list_action("👤 Customer", show_customer_profile)
    backup_btn = make_list_action("💾 Backup", backup_database)
    edit_btn = make_list_action("✏ Edit Selected", edit_selected_reservation)
    payment_btn = make_list_action("💰 Add Payment", add_payment_to_selected, COLOR_SUCCESS, "white")
    export_btn = make_list_action("📤 Export", export_to_spreadsheet)
    receipt_btn = make_list_action("🧾 Receipt", print_receipt)
    cancel_btn = make_list_action("❌ Cancel Reservation", cancel_reservation, COLOR_DANGER, "white")

    add_hover(payment_btn, COLOR_SUCCESS, "#009B42")
    add_hover(cancel_btn, COLOR_DANGER, COLOR_DANGER_HOVER)
    for _btn in action_buttons:
        if _btn is not payment_btn:
            add_hover(_btn, "white", "#F0F2F5")

    table_frame = tk.Frame(main_frame, bg="white", highlightbackground="#084CD4", highlightthickness=1)
    table_frame.pack(padx=30, fill="both", expand=True, pady=(0, 10))

    # ==========================================
    # SECTION NAVIGATION
    # Create Reservation and Reservation List are hidden
    # from the Dashboard until their sidebar buttons are clicked.
    # ==========================================
    def show_create_reservation():
        # Second click toggles the Create Reservation section OFF.
        if form_card.winfo_manager():
            form_card.pack_forget()
            main_canvas_scroll.update_idletasks()
            main_canvas_scroll.yview_moveto(0)
            return

        # Hide reservation list first.
        list_header_row.pack_forget()
        list_action_row.pack_forget()
        table_frame.pack_forget()

        # First click shows the Create Reservation form.
        form_card.pack(fill="x", padx=30, pady=(0, 6))
        main_canvas_scroll.update_idletasks()
        main_canvas_scroll.yview_moveto(0)
        name_entry.focus_set()

    def show_reservation_list():
        # Second click toggles the Reservation List section OFF.
        if list_header_row.winfo_manager():
            list_header_row.pack_forget()
            list_action_row.pack_forget()
            table_frame.pack_forget()
            main_canvas_scroll.update_idletasks()
            main_canvas_scroll.yview_moveto(0)
            return

        # Hide Create Reservation first.
        form_card.pack_forget()

        # First click shows the Reservation List and table.
        list_header_row.pack(fill="x", padx=30, pady=(8, 4))
        list_action_row.pack(fill="x", padx=30, pady=(0, 6))
        table_frame.pack(padx=30, fill="both", expand=True, pady=(0, 10))
        main_canvas_scroll.update_idletasks()
        main_canvas_scroll.yview_moveto(0)
        search_entry.focus_set()

    # Dashboard starts clean: both sections are hidden.
    form_card.pack_forget()
    list_header_row.pack_forget()
    list_action_row.pack_forget()
    table_frame.pack_forget()

    # Sidebar buttons open their corresponding section.
    create_nav_btn.config(command=show_create_reservation)
    list_nav_btn.config(command=show_reservation_list)

    cols = ("No.", "Name", "Contact", "Occasion", "Package", "Date", "Time", "Guests", "Total", "Paid", "Balance", "Status")
    # Keep financial values readable at a glance.
    tree_style = ttk.Style()
    try:
        tree_style.configure("EventEase.Treeview", font=("Segoe UI", 10), rowheight=30)
        tree_style.configure("EventEase.Treeview.Heading", font=("Segoe UI", 8, "bold"))
    except tk.TclError:
        pass
    reservation_table = ttk.Treeview(table_frame, columns=cols, show="headings", height=7, style="EventEase.Treeview")
    for col in cols:
        reservation_table.heading(col, text=col)
    # Give money columns more room so Total / Paid / Balance are easy to read.
    reservation_table.column("No.", width=55, minwidth=55, anchor="center", stretch=False)
    reservation_table.column("Name", width=170, minwidth=140, anchor="w")
    reservation_table.column("Contact", width=120, minwidth=105, anchor="center")
    reservation_table.column("Occasion", width=145, minwidth=120, anchor="center")
    reservation_table.column("Package", width=120, minwidth=105, anchor="center")
    reservation_table.column("Date", width=105, minwidth=95, anchor="center")
    reservation_table.column("Time", width=90, minwidth=80, anchor="center")
    reservation_table.column("Guests", width=75, minwidth=65, anchor="center")
    reservation_table.column("Total", width=125, minwidth=115, anchor="e")
    reservation_table.column("Paid", width=125, minwidth=115, anchor="e")
    reservation_table.column("Balance", width=135, minwidth=125, anchor="e")
    reservation_table.column("Status", width=100, minwidth=90, anchor="center")
    reservation_table.pack(fill="both", expand=True, padx=10, pady=10)

    reservation_table.bind("<Double-1>", lambda _e: edit_selected_reservation())

    load_reservations_from_db()
    update_table()
    update_dashboard()

    def close_main_window():
        try:
            db_conn.commit()
            db_conn.close()
        except Exception:
            pass
        window.destroy()

    window.protocol("WM_DELETE_WINDOW", close_main_window)
    window.mainloop()


# ==========================================
# APP ENTRY POINT
# ==========================================
show_login_screen()